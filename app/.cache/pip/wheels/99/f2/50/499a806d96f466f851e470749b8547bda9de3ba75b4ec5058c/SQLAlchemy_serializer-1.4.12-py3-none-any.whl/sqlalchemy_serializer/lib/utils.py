def get_type(o):
    """
    Handy wrapper for logging purposes
    :param o: any object
    :return str: Nice type name
    """
    return type(o).__name__
